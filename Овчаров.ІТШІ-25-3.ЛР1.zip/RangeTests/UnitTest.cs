﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RangeApp;

namespace RangeTests
{
    [TestClass]
    public class UnitTest
    {
        // [1;5] і [1;5] мають однакові межі, тому рівні
        [TestMethod]
        public void Equals_SameBounds_ReturnsTrue()
        {
            // Arrange
            Range r1 = new Range(1, 5);
            Range r2 = new Range(1, 5);

            // Act
            bool result = r1.Equals(r2);

            // Assert
            Assert.IsTrue(result);
        }

        // [1;5] і [2;5] відрізняються лівою межею, тому не рівні
        [TestMethod]
        public void Equals_DifferentLeft_ReturnsFalse()
        {
            // Arrange
            Range r1 = new Range(1, 5);
            Range r2 = new Range(2, 5);

            // Act
            bool result = r1.Equals(r2);

            // Assert
            Assert.IsFalse(result);
        }

        // [1;5] і [1;8] відрізняються правою межею, тому не рівні
        [TestMethod]
        public void Equals_DifferentRight_ReturnsFalse()
        {
            // Arrange
            Range r1 = new Range(1, 5);
            Range r2 = new Range(1, 8);

            // Act
            bool result = r1.Equals(r2);

            // Assert
            Assert.IsFalse(result);
        }

        // порівняння [1;5] з null дає false
        [TestMethod]
        public void Equals_NullRange_ReturnsFalse()
        {
            // Arrange
            Range r1 = new Range(1, 5);
            Range r2 = null;

            // Act
            bool result = r1.Equals(r2);

            // Assert
            Assert.IsFalse(result);
        }

        // довжина [2;7.5] дорівнює 5.5
        [TestMethod]
        public void Length_PositiveBounds_ReturnsDifference()
        {
            // Arrange
            Range r = new Range(2, 7.5);

            // Act
            double result = r.Length();

            // Assert
            Assert.AreEqual(5.5, result, 1e-9);
        }

        // довжина [-3;4] з від'ємною лівою межею дорівнює 7
        [TestMethod]
        public void Length_NegativeLeft_ReturnsDifference()
        {
            // Arrange
            Range r = new Range(-3, 4);

            // Act
            double result = r.Length();

            // Assert
            Assert.AreEqual(7, result, 1e-9);
        }

        // довжина виродженого діапазону [3;3] дорівнює 0
        [TestMethod]
        public void Length_EqualBounds_ReturnsZero()
        {
            // Arrange
            Range r = new Range(3, 3);

            // Act
            double result = r.Length();

            // Assert
            Assert.AreEqual(0, result, 1e-9);
        }

        // число 2 лежить усередині [-5;5]
        [TestMethod]
        public void Contains_PointInside_ReturnsTrue()
        {
            // Arrange
            Range r = new Range(-5, 5);

            // Act
            bool result = r.Contains(2);

            // Assert
            Assert.IsTrue(result);
        }

        // число -5 збігається з лівою межею [-5;5]
        [TestMethod]
        public void Contains_LeftBound_ReturnsTrue()
        {
            // Arrange
            Range r = new Range(-5, 5);

            // Act
            bool result = r.Contains(-5);

            // Assert
            Assert.IsTrue(result);
        }

        // число 5 збігається з правою межею [-5;5]
        [TestMethod]
        public void Contains_RightBound_ReturnsTrue()
        {
            // Arrange
            Range r = new Range(-5, 5);

            // Act
            bool result = r.Contains(5);

            // Assert
            Assert.IsTrue(result);
        }

        // число -6 лежить лівіше за [-5;5]
        [TestMethod]
        public void Contains_PointLeftOfRange_ReturnsFalse()
        {
            // Arrange
            Range r = new Range(-5, 5);

            // Act
            bool result = r.Contains(-6);

            // Assert
            Assert.IsFalse(result);
        }

        // число 5.1 лежить правіше за [-5;5]
        [TestMethod]
        public void Contains_PointRightOfRange_ReturnsFalse()
        {
            // Arrange
            Range r = new Range(-5, 5);

            // Act
            bool result = r.Contains(5.1);

            // Assert
            Assert.IsFalse(result);
        }

        // [1;6] і [4;10] частково накладаються
        [TestMethod]
        public void Intersects_PartialOverlap_ReturnsTrue()
        {
            // Arrange
            Range r1 = new Range(1, 6);
            Range r2 = new Range(4, 10);

            // Act
            bool result = r1.Intersects(r2);

            // Assert
            Assert.IsTrue(result);
        }

        // [5;8] повністю лежить усередині [0;20]
        [TestMethod]
        public void Intersects_NestedRange_ReturnsTrue()
        {
            // Arrange
            Range r1 = new Range(0, 20);
            Range r2 = new Range(5, 8);

            // Act
            bool result = r1.Intersects(r2);

            // Assert
            Assert.IsTrue(result);
        }

        // [1;4] і [4;9] мають спільну точку 4
        [TestMethod]
        public void Intersects_TouchingBounds_ReturnsTrue()
        {
            // Arrange
            Range r1 = new Range(1, 4);
            Range r2 = new Range(4, 9);

            // Act
            bool result = r1.Intersects(r2);

            // Assert
            Assert.IsTrue(result);
        }

        // [5;9] лежить правіше за [1;4], перетину немає
        [TestMethod]
        public void Intersects_SecondOnRight_ReturnsFalse()
        {
            // Arrange
            Range r1 = new Range(1, 4);
            Range r2 = new Range(5, 9);

            // Act
            bool result = r1.Intersects(r2);

            // Assert
            Assert.IsFalse(result);
        }

        // [1;3] лежить лівіше за [6;9], перетину немає
        [TestMethod]
        public void Intersects_SecondOnLeft_ReturnsFalse()
        {
            // Arrange
            Range r1 = new Range(6, 9);
            Range r2 = new Range(1, 3);

            // Act
            bool result = r1.Intersects(r2);

            // Assert
            Assert.IsFalse(result);
        }

        // перевірка перетину з null має кинути ArgumentNullException
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void Intersects_NullRange_ThrowsArgumentNullException()
        {
            // Arrange
            Range r1 = new Range(1, 4);
            Range r2 = null;

            // Act
            r1.Intersects(r2);

            // Assert
            // очікуваний виняток перевіряє атрибут ExpectedException
        }
    }
}
