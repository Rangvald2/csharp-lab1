﻿namespace RangeApp
{
    public interface IRange
    {
        double Left { get; set; }
        double Right { get; set; }

        bool Equals(IRange other);
        double Length();
        bool Contains(double x);
        bool Intersects(IRange other);
    }
}
