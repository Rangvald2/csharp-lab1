﻿using System;

namespace RangeApp
{
    public class Range : IRange
    {
        private double left;
        private double right;

        public Range()
        {
            left = 0;
            right = 0;
        }

        public Range(double left, double right)
        {
            if (left > right)
                throw new ArgumentException("left > right");
            this.left = left;
            this.right = right;
        }

        public Range(double point)
        {
            left = point;
            right = point;
        }

        public Range(Range other)
        {
            if (other == null)
                throw new ArgumentNullException(nameof(other));
            left = other.left;
            right = other.right;
        }

        public double Left
        {
            get { return left; }
            set
            {
                if (value > right)
                    throw new ArgumentException("left > right");
                left = value;
            }
        }

        public double Right
        {
            get { return right; }
            set
            {
                if (value < left)
                    throw new ArgumentException("right < left");
                right = value;
            }
        }

        public bool Equals(IRange other)
        {
            if (other == null)
                return false;
            return left == other.Left && right == other.Right;
        }

        public double Length()
        {
            return right - left;
        }

        public bool Contains(double x)
        {
            return x >= left && x <= right;
        }

        public bool Intersects(IRange other)
        {
            if (other == null)
                throw new ArgumentNullException(nameof(other));
            return left <= other.Right && other.Left <= right;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as IRange);
        }

        public override int GetHashCode()
        {
            return left.GetHashCode() ^ right.GetHashCode();
        }

        public override string ToString()
        {
            return "[" + left + "; " + right + "]";
        }
    }
}
